package com.example.healthtrack.data.repository

import com.example.healthtrack.data.local.ExerciseDao
import com.example.healthtrack.data.local.MealRecordDao
import com.example.healthtrack.data.local.WaterIntakeDao
import com.example.healthtrack.data.model.Exercise
import com.example.healthtrack.data.model.MealRecord
import com.example.healthtrack.data.model.MealType
import com.example.healthtrack.data.model.WaterIntake
import kotlinx.coroutines.flow.Flow

class HealthRepository(
    private val waterIntakeDao: WaterIntakeDao,
    private val mealRecordDao: MealRecordDao,
    private val exerciseDao: ExerciseDao
) {
    // Water Intake operations
    fun getAllWaterIntakes(): Flow<List<WaterIntake>> = waterIntakeDao.getAllWaterIntakes()

    fun getWaterIntakesForPeriod(startTimestamp: Long, endTimestamp: Long): Flow<List<WaterIntake>> =
        waterIntakeDao.getWaterIntakesForPeriod(startTimestamp, endTimestamp)

    fun getTotalWaterForPeriod(startTimestamp: Long, endTimestamp: Long): Flow<Int?> =
        waterIntakeDao.getTotalWaterForPeriod(startTimestamp, endTimestamp)

    suspend fun insertWaterIntake(waterIntake: WaterIntake): Long =
        waterIntakeDao.insert(waterIntake)

    suspend fun updateWaterIntake(waterIntake: WaterIntake) =
        waterIntakeDao.update(waterIntake)

    suspend fun deleteWaterIntake(waterIntake: WaterIntake) =
        waterIntakeDao.delete(waterIntake)

    // Meal Record operations
    fun getAllMealRecords(): Flow<List<MealRecord>> = mealRecordDao.getAllMealRecords()

    fun getMealRecordsForPeriod(startTimestamp: Long, endTimestamp: Long): Flow<List<MealRecord>> =
        mealRecordDao.getMealRecordsForPeriod(startTimestamp, endTimestamp)

    fun getMealsByType(mealType: MealType): Flow<List<MealRecord>> =
        mealRecordDao.getMealsByType(mealType)

    fun getTotalCaloriesForPeriod(startTimestamp: Long, endTimestamp: Long): Flow<Int?> =
        mealRecordDao.getTotalCaloriesForPeriod(startTimestamp, endTimestamp)

    suspend fun insertMealRecord(mealRecord: MealRecord): Long =
        mealRecordDao.insert(mealRecord)

    suspend fun updateMealRecord(mealRecord: MealRecord) =
        mealRecordDao.update(mealRecord)

    suspend fun deleteMealRecord(mealRecord: MealRecord) =
        mealRecordDao.delete(mealRecord)

    // Exercise operations
    fun getAllExercises(): Flow<List<Exercise>> = exerciseDao.getAllExercises()

    fun getExercisesForPeriod(startTimestamp: Long, endTimestamp: Long): Flow<List<Exercise>> =
        exerciseDao.getExercisesForPeriod(startTimestamp, endTimestamp)

    fun getTotalDurationForPeriod(startTimestamp: Long, endTimestamp: Long): Flow<Int?> =
        exerciseDao.getTotalDurationForPeriod(startTimestamp, endTimestamp)

    fun getTotalCaloriesBurnedForPeriod(startTimestamp: Long, endTimestamp: Long): Flow<Int?> =
        exerciseDao.getTotalCaloriesBurnedForPeriod(startTimestamp, endTimestamp)

    suspend fun insertExercise(exercise: Exercise): Long =
        exerciseDao.insert(exercise)

    suspend fun updateExercise(exercise: Exercise) =
        exerciseDao.update(exercise)

    suspend fun deleteExercise(exercise: Exercise) =
        exerciseDao.delete(exercise)
}
