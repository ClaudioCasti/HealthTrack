package com.example.healthtrack.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.healthtrack.data.local.AppDatabase
import com.example.healthtrack.data.model.WaterIntake
import com.example.healthtrack.data.repository.HealthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Calendar

class WaterIntakeViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: HealthRepository

    init {
        val database = AppDatabase.getDatabase(application)
        repository = HealthRepository(
            database.waterIntakeDao(),
            database.mealRecordDao(),
            database.exerciseDao()
        )
    }

    private val _waterIntakes = MutableStateFlow<List<WaterIntake>>(emptyList())
    val waterIntakes: StateFlow<List<WaterIntake>> = _waterIntakes.asStateFlow()

    private val _todayTotal = MutableStateFlow(0)
    val todayTotal: StateFlow<Int> = _todayTotal.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    init {
        loadWaterIntakes()
        loadTodayTotal()
    }

    private fun loadWaterIntakes() {
        viewModelScope.launch {
            repository.getAllWaterIntakes().collect { intakes ->
                _waterIntakes.value = intakes
            }
        }
    }

    private fun loadTodayTotal() {
        viewModelScope.launch {
            val calendar = Calendar.getInstance()
            calendar.set(Calendar.HOUR_OF_DAY, 0)
            calendar.set(Calendar.MINUTE, 0)
            calendar.set(Calendar.SECOND, 0)
            calendar.set(Calendar.MILLISECOND, 0)
            val startOfDay = calendar.timeInMillis

            calendar.set(Calendar.HOUR_OF_DAY, 23)
            calendar.set(Calendar.MINUTE, 59)
            calendar.set(Calendar.SECOND, 59)
            val endOfDay = calendar.timeInMillis

            repository.getTotalWaterForPeriod(startOfDay, endOfDay).collect { total ->
                _todayTotal.value = total ?: 0
            }
        }
    }

    fun addWaterIntake(amountMl: Int, note: String? = null) {
        if (amountMl <= 0) {
            _message.value = "La cantidad debe ser mayor a 0"
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            try {
                val waterIntake = WaterIntake(
                    amountMl = amountMl,
                    note = note
                )
                repository.insertWaterIntake(waterIntake)
                _message.value = "Agua registrada exitosamente"
            } catch (e: Exception) {
                _message.value = "Error al registrar: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun deleteWaterIntake(waterIntake: WaterIntake) {
        viewModelScope.launch {
            try {
                repository.deleteWaterIntake(waterIntake)
                _message.value = "Registro eliminado"
            } catch (e: Exception) {
                _message.value = "Error al eliminar: ${e.message}"
            }
        }
    }

    fun clearMessage() {
        _message.value = null
    }
}
