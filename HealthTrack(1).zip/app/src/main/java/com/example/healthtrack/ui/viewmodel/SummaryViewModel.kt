package com.example.healthtrack.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.healthtrack.data.local.AppDatabase
import com.example.healthtrack.data.repository.HealthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Calendar

data class DailySummary(
    val totalWaterMl: Int = 0,
    val totalCalories: Int = 0,
    val totalExerciseMinutes: Int = 0,
    val totalCaloriesBurned: Int = 0,
    val mealCount: Int = 0
)

class SummaryViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: HealthRepository

    init {
        val database = AppDatabase.getDatabase(application)
        repository = HealthRepository(
            database.waterIntakeDao(),
            database.mealRecordDao(),
            database.exerciseDao()
        )
    }

    private val _todaySummary = MutableStateFlow(DailySummary())
    val todaySummary: StateFlow<DailySummary> = _todaySummary.asStateFlow()

    private val _weekSummary = MutableStateFlow<List<DailySummary>>(emptyList())
    val weekSummary: StateFlow<List<DailySummary>> = _weekSummary.asStateFlow()

    init {
        loadTodaySummary()
        loadWeekSummary()
    }

    private fun loadTodaySummary() {
        viewModelScope.launch {
            val calendar = Calendar.getInstance()
            calendar.set(Calendar.HOUR_OF_DAY, 0)
            calendar.set(Calendar.MINUTE, 0)
            calendar.set(Calendar.SECOND, 0)
            calendar.set(Calendar.MILLISECOND, 0)
            val startOfDay = calendar.timeInMillis

            calendar.set(Calendar.HOUR_OF_DAY, 23)
            calendar.set(Calendar.MINUTE, 59)
            calendar.set(Calendar.SECOND, 59)
            val endOfDay = calendar.timeInMillis

            launch {
                repository.getTotalWaterForPeriod(startOfDay, endOfDay).collect { water ->
                    _todaySummary.value = _todaySummary.value.copy(totalWaterMl = water ?: 0)
                }
            }

            launch {
                repository.getTotalCaloriesForPeriod(startOfDay, endOfDay).collect { calories ->
                    _todaySummary.value = _todaySummary.value.copy(totalCalories = calories ?: 0)
                }
            }

            launch {
                repository.getTotalDurationForPeriod(startOfDay, endOfDay).collect { duration ->
                    _todaySummary.value = _todaySummary.value.copy(totalExerciseMinutes = duration ?: 0)
                }
            }

            launch {
                repository.getTotalCaloriesBurnedForPeriod(startOfDay, endOfDay).collect { burned ->
                    _todaySummary.value = _todaySummary.value.copy(totalCaloriesBurned = burned ?: 0)
                }
            }

            launch {
                repository.getMealRecordsForPeriod(startOfDay, endOfDay).collect { meals ->
                    _todaySummary.value = _todaySummary.value.copy(mealCount = meals.size)
                }
            }
        }
    }

    private fun loadWeekSummary() {
        viewModelScope.launch {
            val summaries = mutableListOf<DailySummary>()
            val calendar = Calendar.getInstance()

            for (i in 6 downTo 0) {
                calendar.set(Calendar.HOUR_OF_DAY, 0)
                calendar.set(Calendar.MINUTE, 0)
                calendar.set(Calendar.SECOND, 0)
                calendar.set(Calendar.MILLISECOND, 0)
                calendar.add(Calendar.DAY_OF_YEAR, -i)
                val startOfDay = calendar.timeInMillis

                calendar.set(Calendar.HOUR_OF_DAY, 23)
                calendar.set(Calendar.MINUTE, 59)
                calendar.set(Calendar.SECOND, 59)
                val endOfDay = calendar.timeInMillis

                // This is simplified - in production you'd want to collect all data properly
                summaries.add(DailySummary())
                
                calendar.add(Calendar.DAY_OF_YEAR, i)
            }

            _weekSummary.value = summaries
        }
    }

    fun refresh() {
        loadTodaySummary()
        loadWeekSummary()
    }
}
