package com.example.healthtrack.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.healthtrack.data.local.AppDatabase
import com.example.healthtrack.data.model.Exercise
import com.example.healthtrack.data.repository.HealthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ExerciseViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: HealthRepository

    init {
        val database = AppDatabase.getDatabase(application)
        repository = HealthRepository(
            database.waterIntakeDao(),
            database.mealRecordDao(),
            database.exerciseDao()
        )
    }

    private val _exercises = MutableStateFlow<List<Exercise>>(emptyList())
    val exercises: StateFlow<List<Exercise>> = _exercises.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    init {
        loadExercises()
    }

    private fun loadExercises() {
        viewModelScope.launch {
            repository.getAllExercises().collect { exercises ->
                _exercises.value = exercises
            }
        }
    }

    fun addExercise(
        exerciseType: String,
        durationMinutes: Int,
        caloriesBurned: Int?,
        notes: String?
    ) {
        if (exerciseType.isBlank()) {
            _message.value = "El tipo de ejercicio es requerido"
            return
        }

        if (durationMinutes <= 0) {
            _message.value = "La duración debe ser mayor a 0"
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            try {
                val exercise = Exercise(
                    exerciseType = exerciseType,
                    durationMinutes = durationMinutes,
                    caloriesBurned = caloriesBurned,
                    notes = notes
                )
                repository.insertExercise(exercise)
                _message.value = "Ejercicio registrado exitosamente"
            } catch (e: Exception) {
                _message.value = "Error al registrar: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun deleteExercise(exercise: Exercise) {
        viewModelScope.launch {
            try {
                repository.deleteExercise(exercise)
                _message.value = "Registro eliminado"
            } catch (e: Exception) {
                _message.value = "Error al eliminar: ${e.message}"
            }
        }
    }

    fun clearMessage() {
        _message.value = null
    }
}
