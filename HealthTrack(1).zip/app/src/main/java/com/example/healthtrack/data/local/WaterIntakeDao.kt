package com.example.healthtrack.data.local

import androidx.room.*
import com.example.healthtrack.data.model.WaterIntake
import kotlinx.coroutines.flow.Flow

@Dao
interface WaterIntakeDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(waterIntake: WaterIntake): Long

    @Update
    suspend fun update(waterIntake: WaterIntake)

    @Delete
    suspend fun delete(waterIntake: WaterIntake)

    @Query("SELECT * FROM water_intake ORDER BY timestamp DESC")
    fun getAllWaterIntakes(): Flow<List<WaterIntake>>

    @Query("SELECT * FROM water_intake WHERE id = :id")
    suspend fun getWaterIntakeById(id: Long): WaterIntake?

    @Query("SELECT SUM(amountMl) FROM water_intake WHERE timestamp >= :startTimestamp AND timestamp <= :endTimestamp")
    fun getTotalWaterForPeriod(startTimestamp: Long, endTimestamp: Long): Flow<Int?>

    @Query("SELECT * FROM water_intake WHERE timestamp >= :startTimestamp AND timestamp <= :endTimestamp ORDER BY timestamp DESC")
    fun getWaterIntakesForPeriod(startTimestamp: Long, endTimestamp: Long): Flow<List<WaterIntake>>

    @Query("DELETE FROM water_intake")
    suspend fun deleteAll()
}
