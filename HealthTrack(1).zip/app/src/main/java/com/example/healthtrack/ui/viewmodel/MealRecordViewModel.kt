package com.example.healthtrack.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.healthtrack.data.local.AppDatabase
import com.example.healthtrack.data.model.MealRecord
import com.example.healthtrack.data.model.MealType
import com.example.healthtrack.data.repository.HealthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MealRecordViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: HealthRepository

    init {
        val database = AppDatabase.getDatabase(application)
        repository = HealthRepository(
            database.waterIntakeDao(),
            database.mealRecordDao(),
            database.exerciseDao()
        )
    }

    private val _mealRecords = MutableStateFlow<List<MealRecord>>(emptyList())
    val mealRecords: StateFlow<List<MealRecord>> = _mealRecords.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    init {
        loadMealRecords()
    }

    private fun loadMealRecords() {
        viewModelScope.launch {
            repository.getAllMealRecords().collect { records ->
                _mealRecords.value = records
            }
        }
    }

    fun addMealRecord(
        mealType: MealType,
        description: String,
        calories: Int?,
        photoUri: String?,
        latitude: Double?,
        longitude: Double?,
        locationName: String?,
        notes: String?
    ) {
        if (description.isBlank()) {
            _message.value = "La descripción es requerida"
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            try {
                val mealRecord = MealRecord(
                    mealType = mealType,
                    description = description,
                    calories = calories,
                    photoUri = photoUri,
                    latitude = latitude,
                    longitude = longitude,
                    locationName = locationName,
                    notes = notes
                )
                repository.insertMealRecord(mealRecord)
                _message.value = "Comida registrada exitosamente"
            } catch (e: Exception) {
                _message.value = "Error al registrar: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun deleteMealRecord(mealRecord: MealRecord) {
        viewModelScope.launch {
            try {
                repository.deleteMealRecord(mealRecord)
                _message.value = "Registro eliminado"
            } catch (e: Exception) {
                _message.value = "Error al eliminar: ${e.message}"
            }
        }
    }

    fun clearMessage() {
        _message.value = null
    }
}
