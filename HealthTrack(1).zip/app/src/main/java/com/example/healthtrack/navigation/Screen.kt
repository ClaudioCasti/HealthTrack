package com.example.healthtrack.navigation

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object WaterIntake : Screen("water_intake")
    object MealRecord : Screen("meal_record")
    object Exercise : Screen("exercise")
    object History : Screen("history")
    object Summary : Screen("summary")
}
