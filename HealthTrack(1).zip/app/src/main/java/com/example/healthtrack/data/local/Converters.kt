package com.example.healthtrack.data.local

import androidx.room.TypeConverter
import com.example.healthtrack.data.model.MealType

class Converters {
    @TypeConverter
    fun fromMealType(mealType: MealType): String {
        return mealType.name
    }

    @TypeConverter
    fun toMealType(mealType: String): MealType {
        return MealType.valueOf(mealType)
    }
}
