package com.example.healthtrack.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.healthtrack.ui.viewmodel.ExerciseViewModel
import com.example.healthtrack.ui.viewmodel.MealRecordViewModel
import com.example.healthtrack.ui.viewmodel.WaterIntakeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    navController: NavController,
    waterViewModel: WaterIntakeViewModel = viewModel(),
    mealViewModel: MealRecordViewModel = viewModel(),
    exerciseViewModel: ExerciseViewModel = viewModel()
) {
    val waterIntakes by waterViewModel.waterIntakes.collectAsState()
    val mealRecords by mealViewModel.mealRecords.collectAsState()
    val exercises by exerciseViewModel.exercises.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Historial Completo") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, "Volver")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Water Intake Section
            item {
                SectionHeader("Agua 💧", waterIntakes.size)
            }

            items(waterIntakes.take(5)) { intake ->
                WaterIntakeItem(
                    amountMl = intake.amountMl,
                    timestamp = intake.timestamp,
                    note = intake.note,
                    onDelete = { waterViewModel.deleteWaterIntake(intake) }
                )
            }

            // Meals Section
            item {
                Spacer(Modifier.height(8.dp))
                SectionHeader("Comidas 🍽️", mealRecords.size)
            }

            items(mealRecords.take(5)) { meal ->
                MealRecordItem(
                    meal = meal,
                    onDelete = { mealViewModel.deleteMealRecord(meal) }
                )
            }

            // Exercise Section
            item {
                Spacer(Modifier.height(8.dp))
                SectionHeader("Ejercicio 💪", exercises.size)
            }

            items(exercises.take(5)) { exercise ->
                ExerciseItem(
                    exercise = exercise,
                    onDelete = { exerciseViewModel.deleteExercise(exercise) }
                )
            }
        }
    }
}

@Composable
fun SectionHeader(title: String, count: Int) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            title,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Text(
            "($count)",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary
        )
    }
}
