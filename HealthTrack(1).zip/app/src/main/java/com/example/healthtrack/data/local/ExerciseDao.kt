package com.example.healthtrack.data.local

import androidx.room.*
import com.example.healthtrack.data.model.Exercise
import kotlinx.coroutines.flow.Flow

@Dao
interface ExerciseDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(exercise: Exercise): Long

    @Update
    suspend fun update(exercise: Exercise)

    @Delete
    suspend fun delete(exercise: Exercise)

    @Query("SELECT * FROM exercises ORDER BY timestamp DESC")
    fun getAllExercises(): Flow<List<Exercise>>

    @Query("SELECT * FROM exercises WHERE id = :id")
    suspend fun getExerciseById(id: Long): Exercise?

    @Query("SELECT * FROM exercises WHERE timestamp >= :startTimestamp AND timestamp <= :endTimestamp ORDER BY timestamp DESC")
    fun getExercisesForPeriod(startTimestamp: Long, endTimestamp: Long): Flow<List<Exercise>>

    @Query("SELECT SUM(durationMinutes) FROM exercises WHERE timestamp >= :startTimestamp AND timestamp <= :endTimestamp")
    fun getTotalDurationForPeriod(startTimestamp: Long, endTimestamp: Long): Flow<Int?>

    @Query("SELECT SUM(caloriesBurned) FROM exercises WHERE timestamp >= :startTimestamp AND timestamp <= :endTimestamp")
    fun getTotalCaloriesBurnedForPeriod(startTimestamp: Long, endTimestamp: Long): Flow<Int?>

    @Query("DELETE FROM exercises")
    suspend fun deleteAll()
}
