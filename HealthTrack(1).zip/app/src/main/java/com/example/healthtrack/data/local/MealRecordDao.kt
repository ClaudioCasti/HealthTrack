package com.example.healthtrack.data.local

import androidx.room.*
import com.example.healthtrack.data.model.MealRecord
import com.example.healthtrack.data.model.MealType
import kotlinx.coroutines.flow.Flow

@Dao
interface MealRecordDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(mealRecord: MealRecord): Long

    @Update
    suspend fun update(mealRecord: MealRecord)

    @Delete
    suspend fun delete(mealRecord: MealRecord)

    @Query("SELECT * FROM meal_records ORDER BY timestamp DESC")
    fun getAllMealRecords(): Flow<List<MealRecord>>

    @Query("SELECT * FROM meal_records WHERE id = :id")
    suspend fun getMealRecordById(id: Long): MealRecord?

    @Query("SELECT * FROM meal_records WHERE timestamp >= :startTimestamp AND timestamp <= :endTimestamp ORDER BY timestamp DESC")
    fun getMealRecordsForPeriod(startTimestamp: Long, endTimestamp: Long): Flow<List<MealRecord>>

    @Query("SELECT * FROM meal_records WHERE mealType = :mealType ORDER BY timestamp DESC")
    fun getMealsByType(mealType: MealType): Flow<List<MealRecord>>

    @Query("SELECT SUM(calories) FROM meal_records WHERE timestamp >= :startTimestamp AND timestamp <= :endTimestamp")
    fun getTotalCaloriesForPeriod(startTimestamp: Long, endTimestamp: Long): Flow<Int?>

    @Query("DELETE FROM meal_records")
    suspend fun deleteAll()
}
