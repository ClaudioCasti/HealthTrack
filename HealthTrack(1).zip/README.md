# HealthTrack - Aplicación de Seguimiento de Hábitos Saludables

## 📱 Descripción

HealthTrack es una aplicación Android moderna desarrollada con Kotlin y Jetpack Compose que permite a los usuarios registrar y monitorear sus hábitos saludables diarios, incluyendo:

- 💧 **Consumo de agua**: Registra cuánta agua bebes diariamente
- 🍽️ **Comidas**: Registra tus comidas con fotos, calorías y ubicación
- 💪 **Ejercicio**: Registra tus actividades físicas y calorías quemadas
- 📊 **Resumen visual**: Ve tu progreso con estadísticas y gráficos
- 📜 **Historial**: Consulta todos tus registros anteriores

## 🚀 Características Principales

### ✅ Formularios Validados
- Validación de campos requeridos
- Tipos de entrada apropiados (números, texto)
- Mensajes de error claros y útiles

### 📸 Integración de Cámara
- Toma fotos de tus comidas directamente desde la app
- Las fotos se guardan localmente y se asocian con cada registro

### 📍 Geolocalización
- Registra automáticamente la ubicación donde consumes tus alimentos
- Muestra el nombre de la ubicación usando Geocoding
- Funciona con permisos de ubicación fina y aproximada

### 💾 Persistencia Local
- Base de datos Room para almacenamiento local
- Los datos persisten entre sesiones de la app
- No requiere conexión a internet

### 📊 Visualización de Datos
- Resumen diario con metas
- Gráficos de progreso circulares
- Balance calórico (consumidas vs quemadas)
- Indicadores visuales de cumplimiento de metas

## 🛠️ Tecnologías Utilizadas

### Lenguaje y Framework
- **Kotlin**: Lenguaje de programación principal
- **Jetpack Compose**: UI moderna y declarativa
- **Material Design 3**: Componentes de UI modernos

### Arquitectura
- **MVVM**: Model-View-ViewModel
- **Repository Pattern**: Abstracción de fuentes de datos
- **StateFlow**: Manejo reactivo del estado

### Bibliotecas Principales
- **Room**: Base de datos local SQLite
- **Navigation Compose**: Navegación entre pantallas
- **Coil**: Carga y visualización de imágenes
- **CameraX**: API moderna de cámara
- **Google Play Services Location**: Servicios de ubicación
- **Accompanist Permissions**: Manejo de permisos en Compose

## 📦 Estructura del Proyecto

```
com.example.healthtrack/
├── data/
│   ├── local/
│   │   ├── AppDatabase.kt          # Base de datos Room
│   │   ├── Converters.kt           # Convertidores de tipos
│   │   ├── WaterIntakeDao.kt       # DAO para agua
│   │   ├── MealRecordDao.kt        # DAO para comidas
│   │   └── ExerciseDao.kt          # DAO para ejercicios
│   ├── model/
│   │   ├── WaterIntake.kt          # Entidad de agua
│   │   ├── MealRecord.kt           # Entidad de comidas
│   │   └── Exercise.kt             # Entidad de ejercicios
│   └── repository/
│       └── HealthRepository.kt     # Repositorio unificado
├── navigation/
│   ├── Screen.kt                   # Definición de rutas
│   └── AppNavigation.kt            # Configuración de navegación
├── ui/
│   ├── screens/
│   │   ├── HomeScreen.kt           # Pantalla principal
│   │   ├── WaterIntakeScreen.kt    # Registro de agua
│   │   ├── MealRecordScreen.kt     # Registro de comidas
│   │   ├── ExerciseScreen.kt       # Registro de ejercicios
│   │   ├── HistoryScreen.kt        # Historial completo
│   │   └── SummaryScreen.kt        # Resumen y estadísticas
│   ├── viewmodel/
│   │   ├── WaterIntakeViewModel.kt
│   │   ├── MealRecordViewModel.kt
│   │   ├── ExerciseViewModel.kt
│   │   └── SummaryViewModel.kt
│   └── theme/
│       ├── Color.kt
│       ├── Theme.kt
│       └── Type.kt
├── utils/
│   ├── CameraUtils.kt              # Utilidades de cámara
│   ├── LocationHelper.kt           # Ayudante de ubicación
│   └── DateUtils.kt                # Formateo de fechas
└── MainActivity.kt                 # Actividad principal
```

## 🔐 Permisos Requeridos

La aplicación solicita los siguientes permisos:

- **CAMERA**: Para tomar fotos de las comidas
- **ACCESS_FINE_LOCATION**: Para obtener la ubicación precisa
- **ACCESS_COARSE_LOCATION**: Para obtener la ubicación aproximada
- **INTERNET**: Para servicios de geocodificación

## 📱 Pantallas de la Aplicación

### 1. Pantalla Principal (Home)
- Resumen del día actual
- Tarjetas de acceso rápido a cada funcionalidad
- Estadísticas en tiempo real

### 2. Registro de Agua
- Formulario para registrar cantidad de agua
- Visualización del total diario
- Barra de progreso hacia la meta (2000 ml)
- Historial de registros

### 3. Registro de Comidas
- Selección del tipo de comida (Desayuno, Almuerzo, Cena, Snack)
- Descripción de la comida
- Calorías (opcional)
- Foto de la comida (con cámara)
- Ubicación automática
- Notas adicionales

### 4. Registro de Ejercicio
- Tipo de ejercicio
- Duración en minutos
- Calorías quemadas (opcional)
- Notas adicionales

### 5. Historial
- Vista unificada de todos los registros
- Organizado por categorías
- Opciones para eliminar registros

### 6. Resumen y Estadísticas
- Gráficos circulares de progreso
- Metas diarias con porcentajes
- Balance calórico
- Estadísticas del día

## 🔧 Configuración del Proyecto

### Requisitos Previos
- Android Studio Hedgehog o superior
- Kotlin 2.0.21
- SDK mínimo: Android 7.0 (API 24)
- SDK objetivo: Android 15 (API 36)

### Pasos para Ejecutar

1. **Clonar o abrir el proyecto en Android Studio**

2. **Sincronizar Gradle**
   - Android Studio sincronizará automáticamente las dependencias
   - Si no, ejecuta: Build > Sync Project with Gradle Files

3. **Ejecutar la aplicación**
   - Conecta un dispositivo Android o inicia un emulador
   - Click en Run (▶️) o presiona Shift + F10

## 📝 Uso de la Aplicación

### Registrar Agua
1. Desde la pantalla principal, toca "Agua"
2. Presiona el botón flotante (+)
3. Ingresa la cantidad en mililitros
4. Opcionalmente añade una nota
5. Presiona "Guardar"

### Registrar Comida
1. Desde la pantalla principal, toca "Comida"
2. Presiona el botón flotante (+)
3. Selecciona el tipo de comida
4. Ingresa la descripción
5. Opcionalmente:
   - Añade calorías
   - Toma una foto
   - Añade notas
6. La ubicación se captura automáticamente si los permisos están otorgados
7. Presiona "Guardar"

### Registrar Ejercicio
1. Desde la pantalla principal, toca "Ejercicio"
2. Presiona el botón flotante (+)
3. Ingresa el tipo de ejercicio
4. Ingresa la duración
5. Opcionalmente añade calorías quemadas y notas
6. Presiona "Guardar"

### Ver Estadísticas
1. Desde la pantalla principal, toca "Resumen"
2. Visualiza tus metas del día
3. Revisa el balance calórico
4. Presiona el botón de actualizar para refrescar los datos

## 🎯 Metas Predeterminadas

- **Agua**: 2000 ml por día
- **Calorías**: 2000 kcal por día (meta de referencia)
- **Ejercicio**: 30 minutos por día

## 🔄 Base de Datos

La aplicación utiliza Room con las siguientes tablas:

### water_intake
- id (PK)
- amountMl
- timestamp
- note

### meal_records
- id (PK)
- mealType
- description
- calories
- photoUri
- latitude
- longitude
- locationName
- timestamp
- notes

### exercises
- id (PK)
- exerciseType
- durationMinutes
- caloriesBurned
- timestamp
- notes

## 🐛 Solución de Problemas

### La cámara no funciona
- Verifica que los permisos de cámara estén otorgados
- En configuración del dispositivo > Apps > HealthTrack > Permisos

### La ubicación no se captura
- Verifica que los permisos de ubicación estén otorgados
- Activa el GPS/Ubicación en el dispositivo
- Asegúrate de estar al aire libre o cerca de una ventana

### Los datos no se guardan
- Verifica que haya espacio suficiente en el dispositivo
- Revisa los logs de Android Studio para errores

## 📄 Licencia

Este proyecto fue desarrollado como ejemplo educativo.

## 👤 Autor

Desarrollado con ❤️ usando Android Studio y Kotlin

---

## 🔮 Características Futuras Posibles

- [ ] Gráficos semanales y mensuales
- [ ] Exportar datos a CSV
- [ ] Recordatorios para beber agua
- [ ] Widget de pantalla principal
- [ ] Modo oscuro
- [ ] Sincronización en la nube
- [ ] Análisis nutricional avanzado
- [ ] Integración con wearables
- [ ] Compartir logros en redes sociales
