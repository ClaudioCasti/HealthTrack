# 🚀 INSTRUCCIONES DE COMPILACIÓN - HEALTHTRACK

## ⚡ INICIO RÁPIDO

### 1. Abrir en Android Studio
1. Abre Android Studio (versión Hedgehog 2023 o superior)
2. En la pantalla de bienvenida, selecciona **"Open"**
3. Navega a la carpeta: `C:\Users\Franco\Desktop\Coliqueo`
4. Haz clic en **OK**

### 2. Sincronizar Gradle (IMPORTANTE)
Cuando el proyecto se abra:
1. Verás una notificación en la parte superior que dice **"Gradle files have changed"**
2. Haz clic en **"Sync Now"**
3. Espera a que termine la sincronización (5-10 minutos la primera vez)
4. Si hay errores de sincronización:
   - File > Invalidate Caches > Invalidate and Restart
   - Después vuelve a sincronizar

### 3. Configurar SDK (si es necesario)
Si Android Studio te pide descargar SDKs:
1. File > Settings (o Android Studio > Preferences en Mac)
2. Appearance & Behavior > System Settings > Android SDK
3. Marca **Android 15 (API 36)** si no está instalado
4. Haz clic en **Apply** y espera la descarga

### 4. Crear/Seleccionar un Emulador
**Crear nuevo emulador:**
1. Tools > Device Manager
2. Haz clic en **"Create Device"**
3. Selecciona **Pixel 6** (recomendado)
4. Selecciona la imagen del sistema: **Android 14 (API 34)** o superior
5. Si no está descargado, haz clic en **Download** junto al sistema
6. Haz clic en **Next** y luego **Finish**

**O usar dispositivo físico:**
1. Habilita las opciones de desarrollador en tu Android:
   - Configuración > Acerca del teléfono
   - Toca "Número de compilación" 7 veces
2. Configuración > Sistema > Opciones de desarrollador
3. Activa **"Depuración USB"**
4. Conecta el dispositivo por USB
5. Autoriza la depuración cuando aparezca el mensaje

### 5. Compilar y Ejecutar
1. Selecciona tu dispositivo/emulador en el menú desplegable superior
2. Haz clic en el botón verde ▶️ **"Run 'app'"**
3. O presiona **Shift + F10**
4. Espera a que compile (puede tardar 2-5 minutos la primera vez)
5. La app se instalará y abrirá automáticamente

## ⚠️ SOLUCIÓN DE PROBLEMAS COMUNES

### Error: "SDK location not found"
**Solución:**
1. Crea el archivo `local.properties` en la raíz del proyecto
2. Añade la línea: `sdk.dir=C\:\\Users\\TU_USUARIO\\AppData\\Local\\Android\\Sdk`
3. Reemplaza TU_USUARIO con tu nombre de usuario de Windows
4. Sincroniza Gradle nuevamente

### Error: "Plugin with id 'com.google.devtools.ksp' not found"
**Solución:**
1. File > Settings > Plugins
2. Busca "Kotlin Symbol Processing"
3. Si no está instalado, instálalo
4. Reinicia Android Studio
5. Sincroniza Gradle

### Error de compilación de Kotlin
**Solución:**
1. Build > Clean Project
2. Build > Rebuild Project
3. Si persiste, File > Invalidate Caches > Invalidate and Restart

### El emulador no inicia
**Solución:**
1. Verifica que la virtualización esté habilitada en tu BIOS
2. Tools > SDK Manager > SDK Tools
3. Marca "Intel x86 Emulator Accelerator (HAXM installer)"
4. Aplica y reinicia Android Studio

### Error: "Gradle sync failed"
**Solución:**
1. Verifica tu conexión a internet
2. Build > Clean Project
3. File > Invalidate Caches > Invalidate and Restart
4. Vuelve a abrir el proyecto

### La app no se instala en el dispositivo físico
**Solución:**
1. Verifica que la depuración USB esté activa
2. Desconecta y vuelve a conectar el cable USB
3. Revoca las autorizaciones: Opciones de desarrollador > Revocar autorizaciones de depuración USB
4. Vuelve a autorizar cuando conectes

## 📋 VERIFICACIÓN DE LA INSTALACIÓN

Una vez que la app se ejecute, deberías ver:

1. ✅ **Pantalla de Inicio** con:
   - Tarjeta de resumen del día
   - 6 botones de menú (Agua, Comida, Ejercicio, Historial, Resumen, Perfil)

2. ✅ **Funcionalidad de Agua**:
   - Botón flotante (+) para añadir registros
   - Formulario para ingresar cantidad
   - Visualización del total del día

3. ✅ **Funcionalidad de Comida**:
   - Al hacer clic en el botón de foto, solicita permisos de cámara
   - Al guardar, solicita permisos de ubicación
   - Las fotos se guardan y visualizan correctamente

4. ✅ **Funcionalidad de Ejercicio**:
   - Formulario para registrar tipo, duración y calorías
   - Validación de campos requeridos

5. ✅ **Historial**:
   - Muestra todos los registros agrupados por categoría
   - Botones de eliminar funcionan

6. ✅ **Resumen**:
   - Gráficos circulares con porcentajes
   - Estadísticas del día actualizadas

## 🧪 PROBAR FUNCIONALIDADES

### Probar Registro de Agua
1. En la pantalla principal, toca "Agua"
2. Toca el botón (+)
3. Ingresa "250" en cantidad
4. Toca "Guardar"
5. Verifica que aparece en el historial y se actualiza el total

### Probar Registro de Comida con Cámara
1. En la pantalla principal, toca "Comida"
2. Toca el botón (+)
3. Selecciona "Desayuno"
4. Escribe "Tostadas con aguacate"
5. Ingresa "350" en calorías
6. Toca "Foto"
7. Concede permisos de cámara si se solicitan
8. Toma una foto
9. Toca "Guardar"
10. Verifica que la comida aparece con la foto

### Probar Ubicación GPS
1. En el emulador: Tools > More (⋮) > Location
2. Ingresa una ubicación (ej: latitud 40.7128, longitud -74.0060 para NYC)
3. Registra una comida
4. Verifica que aparece la ubicación en el registro

### Probar Ejercicio
1. En la pantalla principal, toca "Ejercicio"
2. Toca el botón (+)
3. Ingresa "Correr" como tipo
4. Ingresa "30" en duración
5. Ingresa "300" en calorías quemadas
6. Toca "Guardar"

### Probar Resumen
1. Registra varios items (agua, comidas, ejercicios)
2. Toca "Resumen" en la pantalla principal
3. Verifica que los gráficos se actualizan
4. Verifica que el balance calórico se calcula correctamente

## 🎯 METAS DE PRUEBA

Para ver la app con datos realistas, ingresa:
- 🥤 Agua: 4-5 registros de 200-500 ml cada uno
- 🍽️ Comidas: 3-4 comidas (desayuno, almuerzo, cena, snack)
- 💪 Ejercicio: 1-2 actividades de 20-60 minutos

## 📱 GENERAR APK PARA INSTALAR

Si quieres generar un APK para instalar en otros dispositivos:

1. Build > Generate Signed Bundle / APK
2. Selecciona **APK**
3. Click **Next**
4. Si no tienes keystore, crea uno nuevo
5. Completa los datos (recuerda la contraseña)
6. Selecciona **release** o **debug**
7. Click **Finish**
8. El APK se generará en: `app/build/outputs/apk/`

Para pruebas rápidas, puedes usar:
- Build > Build Bundle(s) / APK(s) > Build APK(s)
- El APK de debug se genera en: `app/build/outputs/apk/debug/app-debug.apk`

## 🔍 LOGS Y DEPURACIÓN

Para ver logs mientras la app se ejecuta:
1. View > Tool Windows > Logcat
2. Filtra por "HealthTrack" para ver solo logs de tu app
3. Usa diferentes niveles: Verbose, Debug, Info, Warn, Error

## ✅ CHECKLIST FINAL

Antes de considerar la compilación exitosa, verifica:

- [ ] El proyecto sincroniza sin errores
- [ ] La app compila sin errores
- [ ] La app se instala en el dispositivo/emulador
- [ ] La pantalla principal muestra correctamente
- [ ] Los formularios funcionan y validan
- [ ] La cámara funciona (con permisos)
- [ ] La ubicación se captura (con permisos)
- [ ] Los datos se guardan y persisten después de cerrar la app
- [ ] El historial muestra los registros
- [ ] Las estadísticas se calculan correctamente
- [ ] Los gráficos se renderizan correctamente

## 🎉 ¡LISTO!

Si todos los pasos anteriores funcionan correctamente, tu aplicación HealthTrack está completamente funcional y lista para usar.

## 📞 SOPORTE

Si encuentras problemas:
1. Revisa la sección "Solución de problemas comunes" arriba
2. Consulta los logs en Logcat
3. Verifica que todas las dependencias se descargaron correctamente
4. Asegúrate de tener la versión correcta de Android Studio

---

**Versión de la App:** 1.0  
**Última actualización:** Octubre 2025  
**Plataforma objetivo:** Android 7.0+ (API 24+)
